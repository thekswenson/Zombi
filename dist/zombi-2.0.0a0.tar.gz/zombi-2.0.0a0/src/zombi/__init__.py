from typing import Tuple

# The version of Zombi
__version__ = '2.0.0alpha'

# Types
T_PAIR = Tuple[int, int]
